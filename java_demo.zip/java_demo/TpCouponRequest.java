package com.maxFun.ws.vo.request;

import org.codehaus.jackson.annotate.JsonProperty;

public class TpCouponRequest {

	/*
	{
		"coupon_name" :"现金券",
		"coupon_amount":10,
		"min_purchase_price":0,
		"coupon_type":0,
		"coupon_limit":0,
		"campaign_start_time":"2016-05-01 00:00:00",
		"campaign_end_time":"2016-05-05 23:59:59",
		"expiration_interval":1,
		"merchant_id":"88",
		"data_signature":"6F3FCD4608978BA4BDD9067AB2672F78"
	}
	*/
	
	@JsonProperty("coupon_name")
	private String couponName;
	@JsonProperty("coupon_amount")
	private double couponAmount;
	@JsonProperty("min_purchase_price")
	private double minBuyPrice;
	@JsonProperty("coupon_type")
	private Byte couponType;
	@JsonProperty("expiration_interval")
	private Integer expirationInterval;
	@JsonProperty("merchant_id")
	private String merchantId;
	@JsonProperty("campaign_end_time")
	private String campaignEndTime;
	@JsonProperty("campaign_start_time")
	private String campaignStartTime;
	@JsonProperty("data-signature")
	private String dataSignature;
	@JsonProperty("coupon_limit")
	private Integer couponLimit;
	@JsonProperty("data_signature")
	private String dataSignature;
	
	public String getCampaignEndTime() {
		return campaignEndTime;
	}
	public void setCampaignEndTime(String campaignEndTime) {
		this.campaignEndTime = campaignEndTime;
	}
	public String getCampaignStartTime() {
		return campaignStartTime;
	}
	public void setCampaignStartTime(String campaignStartTime) {
		this.campaignStartTime = campaignStartTime;
	}
	public String getDataSignature() {
		return dataSignature;
	}
	public void setDataSignature(String dataSignature) {
		this.dataSignature = dataSignature;
	}
	public Integer getCouponLimit() {
		return couponLimit;
	}
	public void setCouponLimit(Integer couponLimit) {
		this.couponLimit = couponLimit;
	}
	public String getCouponName() {
		return couponName;
	}
	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}
	public Double getCouponAmount() {
		return couponAmount;
	}
	public void setCouponAmount(Double couponAmount) {
		this.couponAmount = couponAmount;
	}
	public Double getMinBuyPrice() {
		return minBuyPrice;
	}
	public void setMinBuyPrice(Double minBuyPrice) {
		this.minBuyPrice = minBuyPrice;
	}
	public Byte getCouponType() {
		return couponType;
	}
	public void setCouponType(Byte couponType) {
		this.couponType = couponType;
	}
	public Integer getExpirationInterval() {
		return expirationInterval;
	}
	public void setExpirationInterval(Integer expirationInterval) {
		this.expirationInterval = expirationInterval;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
}
