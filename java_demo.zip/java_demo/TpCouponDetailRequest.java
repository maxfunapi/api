package com.maxFun.ws.vo.request;

import org.codehaus.jackson.annotate.JsonProperty;

public class TpCouponDetailRequest {

	/*
	{
		"identifier":"18520869180",
		"merchant_id":"11",
		"campaign_id":"3",
		"expiration_time":"2016-07-30 00:00:00",
		"coupon_type":0,
		"coupon_amount":10,
		"min_purchase_price":0,
		"data_signature":"E42EB1F912BF43BEA69F0382FFF440D2"
	}	
	*/

	private String identifier;
	@JsonProperty("merchant_id")
	private String merchantId;
	@JsonProperty("campaign_id")
	private String couponId;
	@JsonProperty("expiration_time")
	private String expirationTime;
	@JsonProperty("coupon_type")
	private Byte couponType;
	@JsonProperty("coupon_amount")
	private double couponAmount;
	@JsonProperty("min_purchase_price")
	private double minBuyPrice;
	@JsonProperty("min_purchase_price")
	private double minBuyPrice;
	@JsonProperty("data_signature")
	private String dataSignature;

	public Byte getCouponType() {
		return couponType;
	}

	public void setCouponType(Byte couponType) {
		this.couponType = couponType;
	}

	public Double getCouponAmount() {
		return couponAmount;
	}

	public void setCouponAmount(Double couponAmount) {
		this.couponAmount = couponAmount;
	}

	public Double getMinBuyPrice() {
		return minBuyPrice;
	}

	public void setMinBuyPrice(Double minBuyPrice) {
		this.minBuyPrice = minBuyPrice;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getCouponId() {
		return couponId;
	}

	public void setCouponId(String couponId) {
		this.couponId = couponId;
	}

	public String getExpirationTime() {
		return expirationTime;
	}

	public void setExpirationTime(String expirationTime) {
		this.expirationTime = expirationTime;
	}

}
