package com.maxFun.admin.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.maxFun.core.util.JSONUtil;

public class SignatureUtil {
	
	public static Boolean checkSignValid(String developerKey, Object requestVO) {
		Map<String, Object> paramMap = JSONUtil.object2Map(requestVO);
		String dataSign = paramMap.get("data_signature") == null ? null : paramMap.get("data_signature").toString();
		paramMap.remove("data_signature");
		if (dataSign == null) {
			return false;
		}
		String sign = signature(developerKey, paramMap);
		return sign.equals(dataSign);
	}
	
	/**
	 * 生成md5密文
	 * @param developerKey
	 * @param map
	 * @return
	 */
	public static String signature(String developerKey, Map<String, Object> map) {
		String paramString  = joinMapValue(map);
		String paramsToStr = paramString + "&key=" +developerKey;
		String signedParams = encryptMD5(paramsToStr);
		return signedParams;
	}
	
	public static String encryptSHA(String inStr)  {
		return encrypt(inStr, "SHA");
    }
	
	public static String encryptMD5(String inStr)  {
		String hexValue = encrypt(inStr, "MD5");
		return hexValue.toUpperCase();
    }
	
	private static String joinMapValue(Map<String, Object> map) {
		List<String> list = new ArrayList<String>(map.keySet());
		Collections.sort(list);
		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < list.size(); i++){
			String key = list.get(i);
			Object value = map.get(key);
			if (map.get(key) != null) {
				if(i == list.size() - 1){//拼接时，不包括最后一个&字符
					 sb.append(key).append("=").append(value);
				} else {
					 sb.append(key).append("=").append(value).append("&");
				}
			}
		}
		String strRet = sb.toString();
		return strRet;
	}

	private static String encrypt(String inStr, String method) {
		MessageDigest sha = null;
        try {
            sha = MessageDigest.getInstance(method);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
        byte[] byteArray;
		try {
			byteArray = inStr.getBytes("UTF-8");
			byte[] md5Bytes = sha.digest(byteArray);
	        StringBuffer hexValue = new StringBuffer();
	        for (int i = 0; i < md5Bytes.length; i++) {
	            int val = ((int) md5Bytes[i]) & 0xff;
	            if (val < 16) { 
	                hexValue.append("0");
	            }
	            hexValue.append(Integer.toHexString(val));
	        }
	        return hexValue.toString();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return "";
		}
	}
}
